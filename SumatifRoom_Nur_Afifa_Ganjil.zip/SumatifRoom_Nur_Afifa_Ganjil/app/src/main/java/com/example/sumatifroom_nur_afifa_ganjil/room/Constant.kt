package com.example.sumatifroom_nur_afifa_ganjil.room

class Constant {
    companion object{
        const val Type_READ = 0
        const val Type_Update = 2
        const val Type_Cerate = 1

    }
}